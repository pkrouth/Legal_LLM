* The .pth files should get downloaded here
* Don't put your models inside this folder beforehand as these files can be large in size, and we want to keep our cloud deployment as light as possible and ask the app to download whatever file it needs
